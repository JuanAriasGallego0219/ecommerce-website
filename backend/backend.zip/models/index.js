module.exports = {
  User: require("./UserModel"),
  Categories: require("./categoriesModel"),
  Product: require("./productModel"),
  ShoppingCart: require("./shoppingCartModel"),
};
